/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import datos.ClienteJpaController;
import dominio.Cliente;

/**
 *
 * @author pc
 */
public class pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        ClienteJpaController daoCliente = new ClienteJpaController();
        daoCliente.create(new Cliente("Prueba"));
    }
    
}
